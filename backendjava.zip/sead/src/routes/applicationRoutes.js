import express from 'express';
import mongoose from 'mongoose';
import PassportApplication from '../models/PassportApplication.js';

const router = express.Router();

router.post('/submit', async (req, res) => {
  try {
    console.log('Received request body:', req.body); // Debug incoming data

    const {
      fullName, dob, address, nationality, gender, phone, fatherName, motherName,
      maritalStatus, appointmentDate, docTypes,
    } = req.body;

    // Basic validation
    if (!fullName || !dob || !address) {
      return res.status(400).json({ message: 'Missing required fields' });
    }

    const application = new PassportApplication({
      userId: new mongoose.Types.ObjectId(), // Dummy userId
      fullName,
      dob,
      address,
      nationality: nationality || 'N/A',
      gender: gender || 'N/A',
      phone: phone || 'N/A',
      fatherName: fatherName || 'N/A',
      motherName: motherName || 'N/A',
      maritalStatus: maritalStatus || 'N/A',
      documents: docTypes ? [{ path: 'test.pdf', type: docTypes[0] || 'Unknown' }] : [],
      appointmentDate: appointmentDate || new Date(),
      status: 'pending',
    });

    const savedApplication = await application.save();
    console.log('Saved application ID:', savedApplication._id); // Debug saved ID

    res.status(201).json({ 
      message: 'Application submitted successfully', 
      applicationId: savedApplication._id.toString()
    });
  } catch (error) {
    console.error('Submission error:', error); // Log exact error
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

router.get('/status/:id', async (req, res) => {
  try {
    const application = await PassportApplication.findOne({ _id: req.params.id });
    if (!application) {
      return res.status(404).json({ message: 'Application not found' });
    }
    res.json(application);
  } catch (error) {
    console.error('Status error:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

export default router;