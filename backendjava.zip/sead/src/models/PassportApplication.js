import mongoose from 'mongoose';

const passportApplicationSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  fullName: { type: String, required: true },
  dob: { type: Date, required: true },
  address: { type: String, required: true },
  nationality: { type: String, required: true },
  gender: { type: String, required: true },
  phone: { type: String, required: true },
  fatherName: { type: String, required: true },
  motherName: { type: String, required: true },
  maritalStatus: { type: String, required: true },
  documents: [{ path: String, type: String }],
  appointmentDate: { type: Date, required: true },
  status: { type: String, default: 'pending' },
}, { timestamps: true });

export default mongoose.model('PassportApplication', passportApplicationSchema);